<?php
include_once("header.php");
?>
<main id="error">
    <div>
    <h1>404</h1>
    <h2>Oups ! La page que vous demandez n'existe pas.</h2>
    </div>
    <p><a href="index.php">Retourner sur la page d'accueil</a></p>
</main>
<?php
include_once("footer.php");
?>